<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "5Ti_g1_mecze2";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

