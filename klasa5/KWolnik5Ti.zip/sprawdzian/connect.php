<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "5Ti_g2_filmy";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

